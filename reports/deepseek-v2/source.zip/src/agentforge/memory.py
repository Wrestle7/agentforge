"""Namespaced cross-session retrieval. Hash mode is lexical, API mode is semantic."""
import hashlib
import math
import re
import uuid

import httpx
from pgvector.sqlalchemy import Vector
from sqlalchemy import Column, JSON, MetaData, String, Table, select, text


class Memory:
    def __init__(self, store, settings):
        self.store, self.settings = store, settings
        self.postgres = store.engine.dialect.name == "postgresql"
        self.embedding_id = f"{settings.embedding_backend}:{settings.embedding_model}:{settings.embedding_dim}"
        if self.postgres:
            with store.engine.begin() as conn:
                conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        meta = MetaData()
        self.table = Table("af_memory", meta, Column("id", String(40), primary_key=True),
                           Column("namespace", String(100), index=True), Column("source_run", String(80)),
                           Column("embedding_id", String(160)), Column("body", JSON),
                           Column("embedding", Vector(settings.embedding_dim) if self.postgres else JSON))
        meta.create_all(store.engine)

    def embed(self, value):
        cfg = self.settings
        if cfg.embedding_backend == "api":
            with httpx.Client(timeout=30) as client:
                response = client.post(cfg.llm_base_url.rstrip("/") + "/embeddings",
                                       headers={"Authorization": f"Bearer {cfg.llm_api_key}"},
                                       json={"model": cfg.embedding_model, "input": value,
                                             "dimensions": cfg.embedding_dim})
                response.raise_for_status()
                vector = response.json()["data"][0]["embedding"]
            if len(vector) != cfg.embedding_dim:
                raise ValueError("embedding dimension mismatch; use a separate DB when changing dimensions")
            return vector
        if cfg.embedding_backend != "hash":
            raise ValueError("AF_EMBEDDING_BACKEND must be hash or api")
        vector = [0.0] * cfg.embedding_dim
        # Unicode word + individual CJK characters. Stable across processes unlike hash().
        tokens = re.findall(r"[a-z0-9_]+|[\u4e00-\u9fff]", value.lower())
        for token in tokens:
            idx = int.from_bytes(hashlib.sha256(token.encode()).digest()[:4], "big") % len(vector)
            vector[idx] += 1
        norm = math.sqrt(sum(v * v for v in vector)) or 1
        return [v / norm for v in vector]

    def add(self, namespace, source_run, body):
        vector = self.embed(body["text"])
        with self.store.engine.begin() as conn:
            conn.execute(self.table.insert().values(id=uuid.uuid4().hex, namespace=namespace,
                         source_run=source_run, body=body, embedding_id=self.embedding_id, embedding=vector))

    def search(self, namespace, query, limit=3, exclude_run=""):
        vector = self.embed(query)
        stmt = select(self.table).where(self.table.c.namespace == namespace,
                                       self.table.c.embedding_id == self.embedding_id,
                                       self.table.c.source_run != exclude_run)
        if self.postgres:
            stmt = stmt.order_by(self.table.c.embedding.cosine_distance(vector)).limit(limit)
        with self.store.engine.connect() as conn:
            rows = list(conn.execute(stmt).mappings())
        if not self.postgres:
            rows.sort(key=lambda r: sum(a * b for a, b in zip(vector, r["embedding"])), reverse=True)
        return [{"source_run": r["source_run"], **r["body"]} for r in rows[:limit]]

